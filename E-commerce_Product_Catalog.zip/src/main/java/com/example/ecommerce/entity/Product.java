package com.example.ecommerce.entity;

import jakarta.persistence.*;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productId;
    private String name;
    private String description;
    private double price;
    private String category;
    private int stockQuantity;

    // Getters and setters omitted for brevity
}
